package com.dubbo.api.service;

import com.dubbo.Student;

import java.util.List;

public interface StudentServiceApi {

    /*
    获取所有学生信息
     */
    public List<Student> getAll();

    /*
    根据姓名查询学生信息
     */
    public List<Student> getByName(String name);
}
