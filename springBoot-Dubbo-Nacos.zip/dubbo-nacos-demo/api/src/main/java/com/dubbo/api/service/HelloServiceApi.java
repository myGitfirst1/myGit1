package com.dubbo.api.service;

public interface HelloServiceApi {

    String sayHello(String name);

}
