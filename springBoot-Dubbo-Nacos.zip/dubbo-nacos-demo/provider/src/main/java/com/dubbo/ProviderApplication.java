package com.dubbo;

import com.alibaba.dubbo.config.spring.context.annotation.EnableDubbo;
//import org.apache.dubbo.config.spring.context.annotation.EnableDubboConfig;
import com.alibaba.nacos.api.config.ConfigType;
import com.alibaba.nacos.spring.context.annotation.config.NacosPropertySource;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@EnableDubbo
@SpringBootApplication
@NacosPropertySource(dataId = "forProvider", autoRefreshed = true, type = ConfigType.YAML)
public class ProviderApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProviderApplication.class, args);
    }
}
