package com.dubbo.service;

import com.alibaba.dubbo.config.annotation.Service;
import com.dubbo.api.service.HelloServiceApi;

@Service
public class HelloServiceImpl implements HelloServiceApi {

    @Override
    public String sayHello(String name) {
        return "ok : 8080 " + name;
    }
}
