package com.dubbo.service;

import com.dubbo.Student;

import com.dubbo.api.service.StudentServiceApi;
import com.dubbo.mapper.StudentMapper;
import org.apache.dubbo.config.annotation.Reference;
import org.apache.dubbo.config.annotation.Service;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Service
public class StudentServiceImpl implements StudentServiceApi {

    //    @Reference   //不行？ 作用是什么？
    @Autowired
    public StudentMapper studentMapper;

    @Override
    public List<Student> getAll() {
        return studentMapper.getAll();
    }

    @Override
    public List<Student> getByName(String name) {
        return studentMapper.getByName(name);
    }
}
