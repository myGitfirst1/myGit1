package com.dubbo.controller;

import com.dubbo.Student;
import com.dubbo.api.service.HelloServiceApi;
import com.dubbo.api.service.StudentServiceApi;
import org.apache.dubbo.config.annotation.Reference;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.POST;

@Controller
public class TestController {

    @Reference
    private HelloServiceApi helloServiceApi;
    @Reference
    private StudentServiceApi studentServiceApi;

    @ResponseBody
    @RequestMapping("/get")
    public List show() {
        return studentServiceApi.getAll();
    }

    /*
    获取所有员工信息
     */

    @RequestMapping(value = "/getStudentAll", method = RequestMethod.GET)
    public ModelAndView showStudentAll() {
        ModelAndView mv = new ModelAndView("templates/index");
        List<Student> list = studentServiceApi.getAll();
        mv.addObject("list", list);
        return mv;
    }
}
