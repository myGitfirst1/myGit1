package com.dubbo.mapper;

import com.dubbo.Student;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface StudentMapper {
    /*
    获取所有员工信息
     */
    public List<Student> getAll();


    /*
    根据名字获取员工信息
     */
    List<Student> getByName(String name);
}
